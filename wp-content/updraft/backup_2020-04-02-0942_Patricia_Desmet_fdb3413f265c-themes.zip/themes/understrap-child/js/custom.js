$(document).ready(function() {

    if (window.matchMedia("(min-width: 992px)").matches) {
        $(window).scroll(function() {
            if ($(window).scrollTop() >= 500) {
                $('#wrapper-navbar').addClass('fixed-header');
            }
            else {
                $('#wrapper-navbar').removeClass('fixed-header');
            }
        });
    }

    $('button.navbar-toggler').on('click', function(){
        alert('Ce code fonctionne !');
    });

});